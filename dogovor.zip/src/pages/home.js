import {InPhoneComponent} from "../components/inPhone"
export const HomePage = () => {

  return (
    <div>
      {/* <h1>Home Page</h1> */}
      <InPhoneComponent />
    </div>
  );
};
