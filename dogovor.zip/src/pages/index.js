export * from "./accessPage"
export * from "./home"
export * from "./loggin"
export * from "./out"