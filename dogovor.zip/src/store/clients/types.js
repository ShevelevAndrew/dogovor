export const GET_CLIENTS_START = "@clients/get access start";
export const GET_CLIENTS_SUCCESS = "@clients/get clients success";
export const GET_CLIENTS_ERROR = "@clients/get clients error";

export const GET_INPHONE_START = "@inphone/get inphone start";
export const GET_INPHONE_SUCCESS = "@inphone/get inphone success";
export const GET_INPHONE_ERROR = "@inphone/get inphone error";
