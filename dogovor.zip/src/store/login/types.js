export const GET_LOGIN_START = "@login/get login start";
export const GET_LOGIN_SUCCESS = "@login/get login success";
export const GET_LOGIN_ERROR = "@login/get login error";
