export const GET_ACCESS_START = "@access/get access start";
export const GET_ACCESS_SUCCESS = "@access/get access success";
export const GET_ACCESS_ERROR = "@access/get access error";
export const CREATE_ACCESS_START = "@access/create access start";
export const CREATE_ACCESS_SUCCESS = "@access/create access success";
export const CREATE_ACCESS_ERROR = "@access/create access error";